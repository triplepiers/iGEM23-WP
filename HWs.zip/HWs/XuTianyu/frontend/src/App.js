import './App.css';
import Myroute from './myroute';

function App() {
  return (
    <div style={{height:'100%'}}>
      <Myroute/>
    </div>
  );
}

export default App;
