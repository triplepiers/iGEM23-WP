Unknown command: "echo"

To see a list of supported npm commands, run:
  npm help
